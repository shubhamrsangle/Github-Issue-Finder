# Github-Issue-Finder
This is like search engine, where you just have to copy pate your bug in search box and all related issues and their status will appear on your screen.
